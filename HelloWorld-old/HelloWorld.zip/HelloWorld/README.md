# HelloWorld

## Package
```
./gradlew distZip
```

